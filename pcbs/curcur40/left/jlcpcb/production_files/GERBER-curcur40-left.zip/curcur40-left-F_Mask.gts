%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-10-17T16:28:00+09:00*%
%TF.ProjectId,curcur40-left,63757263-7572-4343-902d-6c6566742e6b,4.1.0*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-10-17 16:28:00*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.200000X0.850000X-0.850000X0.850000X0.850000X-0.850000X0.850000X-0.850000X-0.850000X0*%
%ADD11O,2.100000X2.100000*%
%ADD12O,1.500000X2.500000*%
%ADD13O,1.500000X2.300000*%
%ADD14O,2.400000X1.600000*%
G04 APERTURE END LIST*
D10*
%TO.C,J4*%
X-273732000Y72773750D03*
D11*
X-276272000Y72773750D03*
X-278812000Y72773750D03*
%TD*%
D12*
%TO.C,J1*%
X-184772000Y118207499D03*
D13*
X-184772000Y114207499D03*
D12*
X-173532000Y118207499D03*
D13*
X-173532000Y114207499D03*
%TD*%
D14*
%TO.C,J2*%
X-167607000Y56603750D03*
X-167607000Y64403750D03*
X-164407000Y56603750D03*
X-164407000Y64403750D03*
%TD*%
M02*
